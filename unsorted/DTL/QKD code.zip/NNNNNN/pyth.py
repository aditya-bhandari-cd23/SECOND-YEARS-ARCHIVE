import json
import heapq
from collections import defaultdict
from flask import Flask, request, jsonify, render_template
import pennylane as qml
import numpy as np
from flask_cors import CORS

app = Flask(__name__)
CORS(app) 

# PennyLane QKD setup
dev = qml.device("default.qubit", wires=2)

@qml.qnode(dev)
def qkd_circuit():
    qml.Hadamard(wires=0)  # Alice applies Hadamard gate
    qml.CNOT(wires=[0, 1])  # Entangle Alice's and Bob's qubits
    return qml.probs(wires=[0, 1])  # Measure the qubits

def simulate_qkd(message_length):
    alice_bases = np.random.randint(0, 2, message_length)  # Alice's bases (0 or 1)
    bob_bases = np.random.randint(0, 2, message_length)    # Bob's bases (0 or 1)

    measurement_probs = qkd_circuit()

    shared_key = []
    for i in range(message_length):
        if alice_bases[i] == bob_bases[i]:
            shared_key.append(int(measurement_probs[alice_bases[i]] > 0.5))

    return alice_bases.tolist(), bob_bases.tolist(), shared_key

# Node definition for Huffman tree
class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq

    def to_dict(self):
        return {
            'char': self.char,
            'freq': self.freq,
            'left': self.left.to_dict() if self.left else None,
            'right': self.right.to_dict() if self.right else None
        }

    @staticmethod
    def from_dict(data):
        node = Node(data['char'], data['freq'])
        if data['left']:
            node.left = Node.from_dict(data['left'])
        if data['right']:
            node.right = Node.from_dict(data['right'])
        return node

def generate_huffman_codes(node, prefix="", codebook=None):
    if codebook is None:
        codebook = {}
    if node is not None:
        if node.char is not None:
            codebook[node.char] = prefix
        generate_huffman_codes(node.left, prefix + "0", codebook)
        generate_huffman_codes(node.right, prefix + "1", codebook)
    return codebook

def huffman_encode(text, codebook):
    return ''.join(codebook[char] for char in text)

def huffman_decode(encoded_text, root):
    decoded_text = []
    node = root
    for bit in encoded_text:
        node = node.left if bit == "0" else node.right
        if node.char is not None:
            decoded_text.append(node.char)
            node = root
    return ''.join(decoded_text)

def build_huffman_tree_from_dict(data):
    return Node.from_dict(data)

@app.route('/')
def index():
    return render_template('index.html')


'''
@app.route('/alice/chat', methods=['POST'])
def alice_chat():
    data = request.get_json()
    message = data.get("message")

    if not message:
        return jsonify({"error": "No message provided"}), 400

    # Huffman encoding the message
    freq = defaultdict(int)
    for char in message:
        freq[char] += 1

    priority_queue = [Node(char, freq) for char, freq in freq.items()]
    heapq.heapify(priority_queue)

    while len(priority_queue) > 1:
        left = heapq.heappop(priority_queue)
        right = heapq.heappop(priority_queue)
        merged = Node(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(priority_queue, merged)

    huffman_tree_root = priority_queue[0]
    codebook = generate_huffman_codes(huffman_tree_root)
    encoded_message = huffman_encode(message, codebook)

    # Simulate QKD using PennyLane
    alice_bases, bob_bases, shared_key = simulate_qkd(len(message))

    data_to_send = {
        'message': message,
        'encoded_message': encoded_message,
        'alice_bases': alice_bases,
        'bob_bases': bob_bases,
        'shared_key': shared_key,
        'huffman_tree_root': huffman_tree_root.to_dict(),
    }

    # Use a JSON file to simulate communication between Alice and Bob
    with open('message_to_terminal_B.json', 'w') as f:
        json.dump(data_to_send, f)

    return jsonify({
        "status": "Message sent to Terminal B", 
        "encoded_message": encoded_message,
        "decoded_message": huffman_decode(encoded_message, huffman_tree_root),
        "shared_key": ''.join(map(str, shared_key))
    })

@app.route('/bob/chat', methods=['POST'])
def bob_chat():
    # Read the message sent to Bob
    try:
        with open('message_to_terminal_B.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "No message found"}), 404

    huffman_tree_root = build_huffman_tree_from_dict(data['huffman_tree_root'])
    encoded_message = data['encoded_message']
    decoded_message = huffman_decode(encoded_message, huffman_tree_root)

    shared_key = data['shared_key']
    original_message = data['message']

    return jsonify({
        "decoded_message": decoded_message,
        "shared_key": ''.join(map(str, shared_key)),
        "original_message": original_message
    })
'''
@app.route('/alice/chat', methods=['POST'])
def alice_chat():
    data = request.get_json()
    message = data.get("message")

    if not message:
        return jsonify({"error": "No message provided"}), 400

    # Huffman encoding the message
    freq = defaultdict(int)
    for char in message:
        freq[char] += 1
    print(char, freq)
    priority_queue = [Node(char, freq) for char, freq in freq.items()]
    heapq.heapify(priority_queue)

    while len(priority_queue) > 1:
        left = heapq.heappop(priority_queue)
        right = heapq.heappop(priority_queue)
        merged = Node(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(priority_queue, merged)

    huffman_tree_root = priority_queue[0]
    codebook = generate_huffman_codes(huffman_tree_root)
    encoded_message = huffman_encode(message, codebook)

    # Simulate QKD using PennyLane
    alice_bases, bob_bases, shared_key = simulate_qkd(len(message))

    data_to_send = {
        'message': message,
        'encoded_message': encoded_message,
        'alice_bases': alice_bases,
        'bob_bases': bob_bases,
        'shared_key': shared_key,
        'huffman_tree_root': huffman_tree_root.to_dict(),
    }

    # Save message for Bob to receive
    with open('message_from_alice.json', 'w') as f:
        json.dump(data_to_send, f)

    # Respond back to Alice with the same message
    return jsonify({
        "status": "Message sent to Terminal B", 
        "encoded_message": encoded_message,
        "decoded_message": huffman_decode(encoded_message, huffman_tree_root),
        "shared_key": ''.join(map(str, shared_key))
    })

# @app.route('/bob/chat', methods=['POST'])
# def bob_chat():
#     # Read the message sent to Bob
#     try:
#         with open('message_from_alice.json', 'r') as f:
#             data = json.load(f)
#     except FileNotFoundError:
#         return jsonify({"error": "No message found from Alice"}), 404

#     huffman_tree_root = build_huffman_tree_from_dict(data['huffman_tree_root'])
#     encoded_message = data['encoded_message']
#     decoded_message = huffman_decode(encoded_message, huffman_tree_root)

#     shared_key = data['shared_key']
#     original_message = data['message']

#     # Now Bob can send his message back to Alice
#     bob_message = request.get_json().get("message")
#     if bob_message:
#         # Huffman encode Bob's message
#         freq = defaultdict(int)
#         for char in bob_message:
#             freq[char] += 1

#         priority_queue = [Node(char, freq) for char, freq in freq.items()]
#         heapq.heapify(priority_queue)

#         while len(priority_queue) > 1:
#             left = heapq.heappop(priority_queue)
#             right = heapq.heappop(priority_queue)
#             merged = Node(None, left.freq + right.freq)
#             merged.left = left
#             merged.right = right
#             heapq.heappush(priority_queue, merged)

#         huffman_tree_root = priority_queue[0]
#         codebook = generate_huffman_codes(huffman_tree_root)
#         encoded_bob_message = huffman_encode(bob_message, codebook)

#         # Save Bob's response message for Alice to receive
#         data_to_send = {
#             'message': bob_message,
#             'encoded_message': encoded_bob_message,
#             'shared_key': shared_key,
#             'huffman_tree_root': huffman_tree_root.to_dict(),
#         }

#         with open('message_from_bob.json', 'w') as f:
#             json.dump(data_to_send, f)

#     return jsonify({
#         "decoded_message": decoded_message,
#         "shared_key": ''.join(map(str, shared_key)),
#         "original_message": original_message
#     })

@app.route('/bob/chat', methods=['POST'])
def bob_chat():
    data = request.get_json()
    message = data.get("message")

    if not message:
        return jsonify({"error": "No message provided"}), 400

    # Huffman encoding the message
    freq = defaultdict(int)
    for char in message:
        freq[char] += 1

    priority_queue = [Node(char, freq) for char, freq in freq.items()]
    heapq.heapify(priority_queue)

    while len(priority_queue) > 1:
        left = heapq.heappop(priority_queue)
        right = heapq.heappop(priority_queue)
        merged = Node(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(priority_queue, merged)

    huffman_tree_root = priority_queue[0]
    codebook = generate_huffman_codes(huffman_tree_root)
    encoded_message = huffman_encode(message, codebook)

    # Simulate QKD using PennyLane
    bob_bases, alice_bases, shared_key = simulate_qkd(len(message))

    data_to_send = {
        'message': message,
        'encoded_message': encoded_message,
        'alice_bases': alice_bases,
        'bob_bases': bob_bases,
        'shared_key': shared_key,
        'huffman_tree_root': huffman_tree_root.to_dict(),
    }

    # Save message for Bob to receive
    with open('message_from_bob.json', 'w') as f:
        json.dump(data_to_send, f)

    # Respond back to Alice with the same message
    return jsonify({
        "status": "Message sent to Terminal A", 
        "encoded_message": encoded_message,
        "decoded_message": huffman_decode(encoded_message, huffman_tree_root),
        "shared_key": ''.join(map(str, shared_key))
    })

@app.route('/alice/receive', methods=['POST'])
def alice_receive():
    # Read Bob's message from the file
    try:
        with open('message_from_bob.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "No message found from Bob"}), 404

    huffman_tree_root = build_huffman_tree_from_dict(data['huffman_tree_root'])
    encoded_message = data['encoded_message']
    decoded_message = huffman_decode(encoded_message, huffman_tree_root)

    shared_key = data['shared_key']
    original_message = data['message']

    return jsonify({
        "decoded_message": decoded_message,
        "shared_key": ''.join(map(str, shared_key)),
        "original_message": original_message
    })

@app.route('/bob/receive', methods=['POST'])
def bob_receive():
    # Read Alice's message from the file
    try:
        with open('message_from_alice.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "No message found from Alice"}), 404

    huffman_tree_root = build_huffman_tree_from_dict(data['huffman_tree_root'])
    encoded_message = data['encoded_message']
    decoded_message = huffman_decode(encoded_message, huffman_tree_root)

    shared_key = data['shared_key']
    original_message = data['message']

    return jsonify({
        "decoded_message": decoded_message,
        "shared_key": ''.join(map(str, shared_key)),
        "original_message": original_message
    })







# @app.route('/alice/chat', methods=['POST'])
# def alice_chat():
#     data = request.get_json()
#     message = data.get("message")

#     if not message:
#         return jsonify({"error": "No message provided"}), 400

#     # Huffman encoding the message
#     freq = defaultdict(int)
#     for char in message:
#         freq[char] += 1

#     priority_queue = [Node(char, freq) for char, freq in freq.items()]
#     heapq.heapify(priority_queue)

#     while len(priority_queue) > 1:
#         left = heapq.heappop(priority_queue)
#         right = heapq.heappop(priority_queue)
#         merged = Node(None, left.freq + right.freq)
#         merged.left = left
#         merged.right = right
#         heapq.heappush(priority_queue, merged)

#     huffman_tree_root = priority_queue[0]
#     codebook = generate_huffman_codes(huffman_tree_root)
#     encoded_message = huffman_encode(message, codebook)

#     # Simulate QKD using PennyLane
#     alice_bases, bob_bases, shared_key = simulate_qkd(len(message))

#     data_to_send = {
#         'message': message,
#         'encoded_message': encoded_message,
#         'alice_bases': alice_bases,
#         'bob_bases': bob_bases,
#         'shared_key': shared_key,
#         'huffman_tree_root': huffman_tree_root.to_dict(),
#     }

#     # Use a JSON file to simulate communication between Alice and Bob
#     with open('message_to_terminal_B.json', 'w') as f:
#         json.dump(data_to_send, f)

#     return jsonify({
#         "status": "Message sent to Terminal B", 
#         "encoded_message": encoded_message,
#         "decoded_message": huffman_decode(encoded_message, huffman_tree_root),
#         "shared_key": ''.join(map(str, shared_key))
#     })

# @app.route('/bob/chat', methods=['POST'])
# def bob_chat():
#     try:
#         with open('message_to_terminal_B.json', 'r') as f:
#             data = json.load(f)
#     except FileNotFoundError:
#         return jsonify({"error": "No message found"}), 404

#     huffman_tree_root = build_huffman_tree_from_dict(data['huffman_tree_root'])
#     encoded_message = data['encoded_message']
#     decoded_message = huffman_decode(encoded_message, huffman_tree_root)

#     shared_key = data['shared_key']
#     original_message = data['message']

#     return jsonify({
#         "decoded_message": decoded_message,
#         "encoded_message": encoded_message,  # Send the encoded message back
#         "shared_key": ''.join(map(str, shared_key)),
#         "original_message": original_message
#     })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')